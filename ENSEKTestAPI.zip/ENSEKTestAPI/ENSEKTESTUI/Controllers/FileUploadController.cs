﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using ENSEKTESTUI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace ENSEKTestUI.Controllers
{
    public class FileUploadController : Controller
    {
        private readonly ILogger<FileUploadController> _logger;
        private const string _apiUrl = @"http://localhost:59135/Process"; // Correct at time of writing

        public FileUploadController(ILogger<FileUploadController> logger)
        {
            _logger = logger;
        }

        [HttpPost("FileUpload")]
        public async Task<IActionResult> Index(IFormFile file)
        {
            // Apply some basic file checks
            if (file == null)
                return BadRequest("Error - file not uploaded");

            if (file.Length == 0)
                return BadRequest("Error - file empty");

            if (!file.FileName.Contains("Meter_Reading.csv"))
                return BadRequest("Error - incorrect file uploaded");

            string tempFilePath = null;

            try
            {
                // Store out file to temp area
                tempFilePath = await ExtractFileToStream(file, null);

                // read file contents and assign to a class (ignore top line)
                var meterReadings = System.IO.File.ReadLines(tempFilePath)
                    .Skip(1)
                    .Select(line => new MeterReading(line))
                    .ToArray();

                using (HttpClient client = new HttpClient())
                {
                    HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, _apiUrl);
                    //client.BaseAddress = new Uri(_apiUrl);

                    string json = JsonConvert.SerializeObject(meterReadings);

                    request.Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                    HttpClient http = new HttpClient();
                    HttpResponseMessage response = await http.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("index", "home");
                        //TODO : Feedback to user
                    }

                }

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }

            return Ok();
        }

        /// <summary>
        /// Store file to a temp. file ( and location) 
        /// </summary>
        /// <param name="file"></param>
        /// <param name="tempFilePath"></param>
        /// <returns></returns>
        private static async Task<string> ExtractFileToStream(IFormFile file, string tempFilePath)
        {
            tempFilePath = Path.GetTempFileName();

            using (var stream = new FileStream(tempFilePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            return tempFilePath;
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}