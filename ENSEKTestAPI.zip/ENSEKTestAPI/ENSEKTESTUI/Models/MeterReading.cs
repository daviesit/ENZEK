﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENSEKTESTUI.Models
{
    public class MeterReading
    {
        public MeterReading(string line)
        {
            var split = line.Split(',');
            AccountId = split[0];
            MeterReadingDateTime = split[1];
            MeterReadValue = split[2];
        }

        public string AccountId { get; set; }
        public string MeterReadingDateTime { get; set; }
        public string MeterReadValue { get; set; }

    }
}
