﻿namespace ENSEKTestAPI.Classes
{
    public interface IValidation
    {
        bool IsValuePresent(string value);
        bool IsCorrectLength(string value, int length);
        bool IsNumeric(string value);
        bool IsDateValid(string value);
    }
}