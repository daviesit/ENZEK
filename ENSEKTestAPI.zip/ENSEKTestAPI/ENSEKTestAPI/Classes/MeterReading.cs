﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENSEKTestAPI.Classes
{
    public class MeterReading
    {
        public int Index { get; set; }
        public int AccountId { get; set; }
        public DateTime MeterReadingDateTime { get; set; }
        public int MeterReadValue { get; set; }
        public bool ValidReading { get; set; }
        public bool MeterReadingProcessed { get; set; }
    }
}
