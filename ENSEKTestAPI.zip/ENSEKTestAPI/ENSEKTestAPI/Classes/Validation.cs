﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENSEKTestAPI.Classes
{
    public class Validation : IValidation
    {
        public bool IsCorrectLength(string value, int length)
        {
            return value.Length <= length;
        }

        public bool IsNumeric(string value)
        {
            return value.All(char.IsNumber);
        }

        public bool IsValuePresent(string value)
        {
            return string.IsNullOrEmpty(value) ? false : true;
        }

        public bool IsDateValid(string value)
        {
            if (!DateTime.TryParse(value, out _))
                return false;

            return true;
        }
    }
}