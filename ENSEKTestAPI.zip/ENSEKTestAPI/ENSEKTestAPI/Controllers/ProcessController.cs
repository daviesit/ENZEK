﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using ENSEKTestAPI.Classes;
using ENSEKTestAPI.DataAccess;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace ENSEKTestAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProcessController : ControllerBase
    {
        /* NOTE : DB IS CREATED VIA STARTUP.CS */

        private readonly ILogger<ProcessController> _logger;
        private readonly IValidation _validation;
        private readonly IAppDbRepository _repo;

        public ProcessController(ILogger<ProcessController> logger,
                                 IValidation validation,
                                 IAppDbRepository repo)
        {
            _logger = logger;
            _validation = validation;
            _repo = repo;
        }


        [HttpPost]
        public ActionResult Post(ArrayList meterReadings)
        {
            var postedMeterReadings = new List<MeterReading>();
            var index = 0;

            // Validate data and staged it out prior to inserting into db
            index = ValidationWrapper(meterReadings, postedMeterReadings, index);

            // Grab valid data and invalid meter reading count
            var validReadings = postedMeterReadings.Where(d => d.ValidReading == true);
            var invalidReadingsCount = postedMeterReadings.Where(d => d.ValidReading == false).Count();

            // Insert valid data 
            InsertMeterReadingData(validReadings);

            // Provide return message
            var returnMessage = @$"Succesful valid inserts: {validReadings.Count()} - Failed invalid inserts {invalidReadingsCount}";

            return StatusCode(200, returnMessage);

        }

        /// <summary>
        /// Wrapper method that validation data in stages prior for insertion
        /// </summary>
        /// <param name="meterReadings"></param>
        /// <param name="postedMeterReadings"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        private int ValidationWrapper(ArrayList meterReadings, List<MeterReading> postedMeterReadings, int index)
        {
            // Perfrom first basic validation and setup list object
            index = ExtractJsonAndValidate(meterReadings, postedMeterReadings, index);

            // TODO : Check for duplicate data (i.e. same meter readings & date)

            // Sort out duplicates and use latest meter reading date 
            FlagOldDuplicateEnteriesAsInvalid(postedMeterReadings);

            // Mark non existing accounts as invalid
            FlagNonExistingAccountsAsInvalid(postedMeterReadings);

            // Mark zero meter reading enteries as invalid 
            FlagZeroMeterReadingsAsInvalid(postedMeterReadings);

            return index;
        }

        private static void FlagZeroMeterReadingsAsInvalid(List<MeterReading> postedMeterReadings)
        {
            var zeroReadings = postedMeterReadings.Where(x => x.MeterReadValue == 0);
            foreach (var item in zeroReadings)
            {
                foreach (var pItem in postedMeterReadings)
                {
                    if (pItem.Index == item.Index)
                        item.ValidReading = false;
                }
            }
        }

        /// <summary>
        /// Mark non existing accounts as invalid
        /// </summary>
        /// <param name="postedMeterReadings"></param>
        private void FlagNonExistingAccountsAsInvalid(List<MeterReading> postedMeterReadings)
        {
            var accounts = _repo.GetAllAccounts();

            var result = postedMeterReadings.Where(p => !accounts.Any(p2 => p2.AccountId == p.AccountId));
            foreach (var item in result)
            {
                foreach (var pItem in postedMeterReadings)
                {
                    if (pItem.AccountId == item.AccountId)
                        item.ValidReading = false;
                }
            }
        }

        /// <summary>
        /// Method to insert meterreading data into DB
        /// </summary>
        /// <param name="finalReadingsList"></param>
        private void InsertMeterReadingData(IEnumerable<MeterReading> finalReadingsList)
        {
            foreach (var item in finalReadingsList)
            {
                if (item.ValidReading == true) // belt and braces
                {
                    var newReading =
                        new ENSEK_MeterReading
                        {
                            AccountId = item.AccountId,
                            MeterReadingDateTime = item.MeterReadingDateTime,
                            MeterReadValue = item.MeterReadValue,
                            Updated = DateTime.Now,
                            UserId = 1
                        };

                    _repo.AddEntity(newReading);
                }
            }

            _repo.SaveAll();
        }

        /// <summary>
        /// Extract json and store out to postedMeterReadings object
        /// </summary>
        /// <param name="meterReadings"></param>
        /// <param name="postedMeterReadings"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        private int ExtractJsonAndValidate(ArrayList meterReadings, List<MeterReading> postedMeterReadings, int index)
        {
            foreach (var item in meterReadings)
            {
                {
                    // Deserialize and temporary store out
                    var jsonTextLine = JsonConvert.DeserializeObject<TempMeterReadingContainer>(item.ToString());

                    // Scan through data line and sniff out any discrepancies and create a pass/fail list
                    VaildateUploadedMeterReadings(postedMeterReadings, jsonTextLine, index);
                    index++;
                }
            }

            return index;
        }

        /// <summary>
        /// Method to flag old duplicate enteries as invalid (won't be proccessed later on)  
        /// </summary>
        /// <param name="postedMeterReadings"></param>
        private static void FlagOldDuplicateEnteriesAsInvalid(List<MeterReading> postedMeterReadings)
        {
            // Get a list of duplicate entries
            var duplicates = postedMeterReadings.GroupBy(s => s.AccountId)
                            .SelectMany(s => s.Skip(1)).ToList();

            // Reorder those duplicates and take the newest date 
            // i.e. 6776 10/05/2019 - will be selected as newest date
            var latestMeterReading = postedMeterReadings
                   .Where(x => duplicates.Any(y => y.AccountId == x.AccountId && x.ValidReading == true))
                   .OrderByDescending(y => y.MeterReadingDateTime).Take(1);

            // loop through postedMeterReadings list and flag old dates as not valid
            foreach (var item in postedMeterReadings)
            {
                foreach (var lmr in latestMeterReading)
                {
                    if (item.AccountId == lmr.AccountId)
                        if (item.Index != lmr.Index)
                            item.ValidReading = false; // mark as invalid for all old enteries
                }
            }
        }

        /// <summary>
        /// Calling method to validate data values posted and ity will help to identify what reading is invalid/valid
        /// </summary>
        /// <param name="postedMeterReadings"></param>
        /// <param name="jsonTextLine"></param>
        private void VaildateUploadedMeterReadings(List<MeterReading> postedMeterReadings, TempMeterReadingContainer jsonTextLine, int index)
        {

            if (
                _validation.IsValuePresent(jsonTextLine.AccountId) &&
                _validation.IsCorrectLength(jsonTextLine.AccountId, 4) &&
                _validation.IsValuePresent(jsonTextLine.MeterReadValue) &&
                _validation.IsCorrectLength(jsonTextLine.MeterReadValue, 5) &&
                _validation.IsNumeric(jsonTextLine.MeterReadValue) &&
                _validation.IsDateValid(jsonTextLine.MeterReadingDateTime)
                )
            {
                postedMeterReadings.Add(new MeterReading
                {
                    AccountId = int.Parse(jsonTextLine.AccountId),
                    MeterReadingDateTime = DateTime.ParseExact(jsonTextLine.MeterReadingDateTime, "dd/MM/yyyy HH:mm", new CultureInfo("en-GB")),
                    MeterReadValue = int.Parse(jsonTextLine.MeterReadValue),
                    ValidReading = true,
                    Index = index
                });
            }
            else
            {
                postedMeterReadings.Add(new MeterReading
                {
                    AccountId = _validation.IsValuePresent(jsonTextLine.AccountId) ? int.Parse(jsonTextLine.AccountId) : 0,
                    ValidReading = false,
                    Index = index
                });
            }

        }

    }
}
