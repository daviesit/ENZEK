﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ENSEKTestAPI.DataAccess
{
    public class AppDbRepository : IAppDbRepository
    {
        private readonly AppDbContext _ctx;

        public AppDbRepository(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public IEnumerable<ENSEK_Accounts> GetAllAccounts()
        {
            return _ctx.ENSEK_Accounts
                .OrderBy(P => P.AccountId)
                .ToList();
        }

        public IEnumerable<ENSEK_MeterReading> GetAccountReadingsByAccountId(int? accountId)
        {
            if (!accountId.HasValue)
                return null;

            return _ctx.ENSEK_MeterReading
                .Where(P => P.AccountId == accountId)
                .ToList();
        }

        public void AddEntity(object model)
        {
            _ctx.Add(model);
        }

        public void UpdateEntity(object model)
        {
            _ctx.Update(model);
        }
       
        public bool SaveAll()
        {
            return _ctx.SaveChanges() > 0;
        }
    }
}
