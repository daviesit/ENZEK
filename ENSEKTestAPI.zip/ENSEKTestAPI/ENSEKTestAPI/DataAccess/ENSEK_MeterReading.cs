﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ENSEKTestAPI.DataAccess
{
    [Table("ENSEK_MeterReading")]
    public class ENSEK_MeterReading
    {
        [Column("Id")]
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Required]
        public int Id { get; set; }

        [Required]
        public int AccountId { get; set; }

        [Required]
        public DateTime MeterReadingDateTime { get; set; }

        [Required]
        public int MeterReadValue { get; set; }

        [Required]
        public DateTime Updated { get; set; }

        [Required]
        public int UserId { get; set; }
    }
}
