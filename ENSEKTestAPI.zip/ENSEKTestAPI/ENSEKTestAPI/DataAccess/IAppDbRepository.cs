﻿using System.Collections.Generic;

namespace ENSEKTestAPI.DataAccess
{
    public interface IAppDbRepository
    {
        IEnumerable<ENSEK_Accounts> GetAllAccounts();

        IEnumerable<ENSEK_MeterReading> GetAccountReadingsByAccountId(int? accountId);
        void AddEntity(object model);
        void UpdateEntity(object model);
        bool SaveAll();
    }
}