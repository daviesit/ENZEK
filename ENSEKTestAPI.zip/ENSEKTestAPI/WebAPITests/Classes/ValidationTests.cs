﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ENSEKTestAPI.Classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace ENSEKTestAPI.Classes.Tests
{

    [TestClass()]
    public class ValidationTests
    {

        private readonly IValidation _validation;

        [TestMethod()]
        public void IsCorrectLengthTest()
        {
            var result = _validation.IsCorrectLength("four", 4);
            Assert.AreEqual(4, result);
        }
    }
}